//
//  cmdline.h
//  msdScript
//
//  Created by Justin Siebenhaar on 1/19/21.
//

#ifndef cmdline_h
#define cmdline_h

void use_arguments(int argc, char* argv[]);

#endif /* cmdline_h */
