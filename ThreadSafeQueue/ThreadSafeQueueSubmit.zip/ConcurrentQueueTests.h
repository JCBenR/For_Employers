//
// Created by Justin Siebenhaar on 3/30/21.
//

#ifndef THREADSAFEQUEUE_CONCURRENTQUEUETESTS_H
#define THREADSAFEQUEUE_CONCURRENTQUEUETESTS_H

class ConcurrentQueueTests{
    public:
        static bool testQueue(int producers, int consumers, int ints);

};


#endif //THREADSAFEQUEUE_CONCURRENTQUEUETESTS_H
